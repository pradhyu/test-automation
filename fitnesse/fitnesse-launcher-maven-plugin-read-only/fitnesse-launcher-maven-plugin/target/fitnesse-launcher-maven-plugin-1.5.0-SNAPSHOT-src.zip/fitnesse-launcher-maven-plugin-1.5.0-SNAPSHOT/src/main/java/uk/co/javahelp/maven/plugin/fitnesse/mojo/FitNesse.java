package uk.co.javahelp.maven.plugin.fitnesse.mojo;

interface FitNesse {
	
	String groupId = "org.fitnesse";

	String artifactId = "fitnesse";
	
	String artifactKey = groupId + ":" + artifactId;
}
