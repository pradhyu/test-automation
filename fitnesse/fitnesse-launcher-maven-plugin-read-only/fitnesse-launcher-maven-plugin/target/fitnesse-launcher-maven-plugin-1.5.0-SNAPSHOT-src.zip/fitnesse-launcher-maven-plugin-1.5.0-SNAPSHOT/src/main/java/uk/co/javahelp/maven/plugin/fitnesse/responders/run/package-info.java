/**
 * A parallel package to {@link fitnesse.responders.run}.
 */
package uk.co.javahelp.maven.plugin.fitnesse.responders.run;
