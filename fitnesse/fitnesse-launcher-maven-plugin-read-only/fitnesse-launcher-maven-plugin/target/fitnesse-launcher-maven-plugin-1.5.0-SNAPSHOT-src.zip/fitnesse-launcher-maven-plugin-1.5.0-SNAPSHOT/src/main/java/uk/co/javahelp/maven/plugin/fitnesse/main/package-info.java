/**
 * A parallel package to {@link fitnesseMain}.
 */
package uk.co.javahelp.maven.plugin.fitnesse.main;
