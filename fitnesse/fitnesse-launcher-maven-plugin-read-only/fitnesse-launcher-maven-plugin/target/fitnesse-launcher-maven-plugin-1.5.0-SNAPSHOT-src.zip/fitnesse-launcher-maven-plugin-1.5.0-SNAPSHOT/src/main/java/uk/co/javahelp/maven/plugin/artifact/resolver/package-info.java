/**
 * A parallel package to {@link org.apache.maven.artifact.resolver}.
 */
package uk.co.javahelp.maven.plugin.artifact.resolver;
