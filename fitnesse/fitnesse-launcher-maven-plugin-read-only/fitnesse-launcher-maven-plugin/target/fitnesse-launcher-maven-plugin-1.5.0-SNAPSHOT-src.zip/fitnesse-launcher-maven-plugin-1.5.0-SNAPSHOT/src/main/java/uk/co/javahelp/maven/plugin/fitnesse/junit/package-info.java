/**
 * A parallel package to {@link fitnesse.junit}.
 */
package uk.co.javahelp.maven.plugin.fitnesse.junit;
